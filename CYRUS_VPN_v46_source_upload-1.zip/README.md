# CYRUS VPN v46 — rebuild base

This is a clean Flutter Android baseline for CYRUS VPN using the `sing_box` package.

## What changed from the v45 workflow

- The v45 source sends WireGuard JSON through `flutter_v2ray_client` / `startV2Ray`.
- v46 uses one sing-box engine for WireGuard and supported proxy protocols.
- WireGuard has its own UI tab, filtered profile list, and intake validation; proxy profiles cannot be added from the WireGuard screen and vice versa.
- Connection status and traffic stats are read from the engine streams.
- Ping and speed are requested from engine test APIs; no hard-coded demo values.
- The UI is independently branded CYRUS with a dark navy / cyan / purple visual system.
- Both sections use the same sing-box core, while keeping their profiles and user-facing controls separated. They are not two simultaneously running VPN engines.
- Start/stop sequencing is delegated to the sing-box package API.

## Build

Push this folder to a GitHub repository and run **Actions → CYRUS VPN v46 Android build**.
The workflow runs `flutter analyze`, `flutter test`, then creates split APKs.

## Important limits before release

- This is a new v46 baseline, not a claim that an APK has already been built or device-tested.
- Real VPN testing still must be done on a physical Android device with valid server profiles.
- sing-box share links listed in its documentation are supported. Some legacy formats (including SSR and XHTTP) are not supported by the documented parser.
- The `sing_box` package and sing-box core are GPL-3.0-or-later. If distributing an app linked with them, comply with the license and publish corresponding source and notices.
- Never publish real private keys, passwords, or subscription URLs in the repository.

## Current source basis

The supplied v45 workflow was inspected. Its WireGuard path builds an Xray JSON outbound with `protocol: wireguard` and starts it through `V2ray.startV2Ray`. v46 replaces that approach rather than trying to disguise it as a separate engine.
